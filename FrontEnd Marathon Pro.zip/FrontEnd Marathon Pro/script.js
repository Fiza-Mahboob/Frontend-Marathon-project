
// Animation for about section 
 gsap.from(".about-text", { opacity: 0, x: -50, duration: 1 });
gsap.from(".about-image", { opacity: 0, x: 50, duration: 1, delay: 0.5 });

   // Theme Toggle Button
document.addEventListener("DOMContentLoaded", () => {
    const toggleBtn = document.querySelector(".toggle-btn");
    const root = document.documentElement;
let isBlue = getComputedStyle(root).getPropertyValue("--primary-color").trim() === "#00c3ff";
toggleBtn.addEventListener("click", () => {
        if (isBlue) {
            root.style.setProperty("--primary-color", "#ff7f11"); // Orange shade
            toggleBtn.style.backgroundColor = "#ff7f11"; // Change button background to orange
        } else {
            root.style.setProperty("--primary-color", "#00c3ff"); // Blue shade
            toggleBtn.style.backgroundColor = "#00c3ff"; // Change button background to blue
        }
        isBlue = !isBlue; // Toggle state
    });
});

document.addEventListener("DOMContentLoaded", function() {
// GSAP Prohect Page Banner Animation
    gsap.from(".projects-banner h1", { opacity: 0, y: -50, duration: 1, ease: "power3.out" });
    gsap.from(".projects-banner p", { opacity: 0, y: 20, duration: 1, delay: 0.5, ease: "power3.out" });
// GSAP Project Card Animation
    gsap.from(".project-card", {
        opacity: 0, y: 50, duration: 1, delay: 1, stagger: 0.3, ease: "power3.out"
    });
});

// Hero Text Animation code
document.addEventListener("DOMContentLoaded", function () {
    const textElement = document.getElementById("animated-text");
    const text = "Transforming ideas into impactful digital solutions..";
    let index = 0;

    function typeEffect() {
        if (index < text.length) {
            textElement.textContent += text[index];
            index++;
            setTimeout(typeEffect, 50);
        }
    }

    textElement.textContent = "";
    typeEffect();
});


//On Show more  btn popup Modal 
document.addEventListener("DOMContentLoaded", function() {
        // Get modal and close button elements
        const modal = document.getElementById('serviceModal');
        const closeBtn = document.querySelector('.close');
        
        // Open modal function
        function openModal(button) {
            // Get the parent service card
            const serviceCard = button.closest('.service-box');
            const detail = serviceCard.getAttribute('data-detail');
            const title = serviceCard.querySelector('h3').textContent; 
        
            // Set modal content inside the modalContent div
            const modalTitle = modal.querySelector('#modalTitle');
            const modalDescription = modal.querySelector('#modalDescription');
            
            // Set the modal title and description
            modalTitle.textContent = title;
            modalDescription.textContent = detail;
        
            // Show the modal
            modal.classList.add('show');
        }
        
        // Close modal
        closeBtn.addEventListener('click', () => {
            modal.classList.remove('show');
        });
    
        // Close modal if clicked outside of modal content
        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('show');
            }
        });
    
        // Attach event listeners to each "Show More" button
        const buttons = document.querySelectorAll('.details');
        buttons.forEach(button => {
            button.addEventListener('click', function() {
                openModal(button); // Open modal on button click
            });
        });
    });
    
// Simple code for Slider
document.addEventListener("DOMContentLoaded", function () {
    const swiper = new Swiper('.mySwiper', {
        loop: true,
        pagination: {
            el: '.swiper-pagination',
            clickable: true, // Allows user clicks
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        autoplay: {
            delay: 2000,
            disableOnInteraction: false,
        },
        spaceBetween: 20,
        slidesPerView: 1,
    });
});

    
    